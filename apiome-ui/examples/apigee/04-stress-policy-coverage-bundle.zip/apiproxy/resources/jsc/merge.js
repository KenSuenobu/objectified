// Merges the entitlement callout's response into the request context.
var entitlement = context.getVariable('entitlementResponse.content');
if (entitlement) { context.setVariable('request.header.X-Entitlement', entitlement); }
